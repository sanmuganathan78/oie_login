<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Customer_model extends CI_Model {

	public function add($data)
	{
		$this->db->insert('addcustomer',$data);
		return $this->db->affected_rows()!=1? false:true;
	}

	public function view_cus()
	{
		$this->db->select('*');
		$this->db->from('addcustomer');
		return $this->db->get()->result_array();
	}



	public function select($id,$data)
	{
		$this->db->where('id',$id);
		$this->db->update('addcustomer',$data);
		return $this->db->affected_rows()!=1? false:true;
	}

	public function birthday()
	{
		$this->db->select('*');
		$this->db->where('dob',date('Y-m-d'));
		$this->db->from('addcustomer');
		return $this->db->get()->result_array();
	}


	public function anniversary()
	{
		$this->db->select('*');
		$this->db->where('anniversaryday',date('Y-m-d'));
		$this->db->from('addcustomer');
		return $this->db->get()->result_array();
	}

	    public function birthday_search()
    {
        if($this->input->post('fromdate')=='')
        {
            $fromdate='';
        }
        else
        {
            $fromdate=date('Y-m-d',strtotime($this->input->post('fromdate')));
        }
        if($this->input->post('todate')=='')
        {
            $todate='';
        }
        else
        {
            $todate=date('Y-m-d',strtotime($this->input->post('todate')));
        }
        if(@$fromdate)
        {
            $this->db->where('date >=',$fromdate);
        }
        if(@$todate)
        {
            $this->db->where('date <=',$todate);
        }
        return $query= $this->db->get('addcustomer')->result_array();
    }

        public function anniversary_search()
    {
        if($this->input->post('fromdate')=='')
        {
            $fromdate='';
        }
        else
        {
            $fromdate=date('Y-m-d',strtotime($this->input->post('fromdate')));
        }
        if($this->input->post('todate')=='')
        {
            $todate='';
        }
        else
        {
            $todate=date('Y-m-d',strtotime($this->input->post('todate')));
        }
        if(@$fromdate)
        {
            $this->db->where('date >=',$fromdate);
        }
        if(@$todate)
        {
            $this->db->where('date <=',$todate);
        }
        return $query= $this->db->get('addcustomer')->result_array();
    }



}


