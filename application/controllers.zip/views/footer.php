<script type="text/javascript" src="<?php echo base_url();?>assets/js/libs/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>plugins/jquery-ui/jquery-ui-1.10.2.custom.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/libs/lodash.compat.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>plugins/touchpunch/jquery.ui.touch-punch.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>plugins/event.swipe/jquery.event.move.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>plugins/event.swipe/jquery.event.swipe.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/libs/breakpoints.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>plugins/respond/respond.min.js"></script> <!-- Polyfill for min/max-width CSS3 Media Queries (only for IE8) -->
<script type="text/javascript" src="<?php echo base_url();?>plugins/cookie/jquery.cookie.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>plugins/slimscroll/jquery.slimscroll.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>plugins/slimscroll/jquery.slimscroll.horizontal.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>plugins/sparkline/jquery.sparkline.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>plugins/daterangepicker/moment.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>plugins/daterangepicker/daterangepicker.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>plugins/blockui/jquery.blockUI.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>plugins/pickadate/picker.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>plugins/pickadate/picker.date.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>plugins/pickadate/picker.time.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>plugins/bootstrap-colorpicker/bootstrap-colorpicker.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>plugins/noty/jquery.noty.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>plugins/noty/layouts/top.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>plugins/noty/themes/default.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>plugins/nprogress/nprogress.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>plugins/bootbox/bootbox.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/app.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins.form-components.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>plugins/validation/jquery.validate.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>plugins/noty/jquery.noty.js"></script>
<script type="text/javascript" src="<?Php echo base_url();?>plugins/slimscroll/jquery.slimscroll.min.js"></script>
<script type="text/javascript" src="<?Php echo base_url();?>plugins/select2/select2.min.js"></script> 
<script type="text/javascript" src="<?Php echo base_url();?>plugins/datatables/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="<?Php echo base_url();?>plugins/datatables/DT_bootstrap.js"></script>
<script type="text/javascript" src="<?Php echo base_url();?>plugins/datatables/responsive/datatables.responsive.js"></script> 
<script>
	$(document).ready(function(){
		"use strict";
App.init(); // Init layout and core plugins
Plugins.init(); // Init all plugins
FormComponents.init(); // Init all form-specific plugins
});
</script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/custom.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/demo/ui_general.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/demo/pages_calendar.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/demo/charts/chart_filled_blue.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/demo/charts/chart_simple.js"></script>
