<script type="text/javascript" src="<?php echo base_url();?>assets/js/libs/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>plugins/jquery-ui/jquery-ui-1.10.2.custom.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/libs/breakpoints.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>plugins/sparkline/jquery.sparkline.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>plugins/daterangepicker/moment.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/app.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins.form-components.js"></script>
<script type="text/javascript" src="<?Php echo base_url();?>plugins/slimscroll/jquery.slimscroll.min.js"></script>
<script type="text/javascript" src="<?Php echo base_url();?>plugins/select2/select2.min.js"></script> 
<script type="text/javascript" src="<?Php echo base_url();?>plugins/datatables/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="<?Php echo base_url();?>plugins/datatables/DT_bootstrap.js"></script>
<script>
  $(document).ready(function(){
    "use strict";
App.init(); // Init layout and core plugins
Plugins.init(); // Init all plugins
FormComponents.init(); // Init all form-specific plugins
});
</script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/demo/ui_general.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/demo/pages_calendar.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/demo/charts/chart_filled_blue.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/demo/charts/chart_simple.js"></script>
