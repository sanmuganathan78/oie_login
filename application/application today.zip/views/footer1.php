
 
  <script type="text/javascript" src="assets/js/libs/lodash.compat.min.js"></script>

  
  <script type="text/javascript" src="plugins/touchpunch/jquery.ui.touch-punch.min.js"></script>
  <script type="text/javascript" src="plugins/event.swipe/jquery.event.move.js"></script>
  <script type="text/javascript" src="plugins/event.swipe/jquery.event.swipe.js"></script>

  <script type="text/javascript" src="assets/js/libs/breakpoints.js"></script>
  <script type="text/javascript" src="plugins/cookie/jquery.cookie.min.js"></script>
  <script type="text/javascript" src="plugins/slimscroll/jquery.slimscroll.min.js"></script>
  <script type="text/javascript" src="plugins/slimscroll/jquery.slimscroll.horizontal.min.js"></script>

  <script type="text/javascript" src="plugins/sparkline/jquery.sparkline.min.js"></script>

  <script type="text/javascript" src="plugins/daterangepicker/moment.min.js"></script>
  <script type="text/javascript" src="plugins/daterangepicker/daterangepicker.js"></script>
  <script type="text/javascript" src="plugins/blockui/jquery.blockUI.min.js"></script>

  <script type="text/javascript" src="plugins/typeahead/typeahead.min.js"></script> 
  <script type="text/javascript" src="plugins/autosize/jquery.autosize.min.js"></script>
  <script type="text/javascript" src="plugins/inputlimiter/jquery.inputlimiter.min.js"></script>
  <script type="text/javascript" src="plugins/uniform/jquery.uniform.min.js"></script>
  <script type="text/javascript" src="plugins/tagsinput/jquery.tagsinput.min.js"></script>
  <script type="text/javascript" src="plugins/select2/select2.min.js"></script> 
  <script type="text/javascript" src="plugins/fileinput/fileinput.js"></script>
  <script type="text/javascript" src="plugins/duallistbox/jquery.duallistbox.min.js"></script>
  <script type="text/javascript" src="plugins/bootstrap-inputmask/jquery.inputmask.min.js"></script>
  <script type="text/javascript" src="plugins/bootstrap-wysihtml5/wysihtml5.min.js"></script>
  <script type="text/javascript" src="plugins/bootstrap-wysihtml5/bootstrap-wysihtml5.min.js"></script>
  <script type="text/javascript" src="plugins/bootstrap-multiselect/bootstrap-multiselect.min.js"></script>

  <script type="text/javascript" src="plugins/globalize/globalize.js"></script>
  <script type="text/javascript" src="plugins/globalize/cultures/globalize.culture.de-DE.js"></script>
  <script type="text/javascript" src="plugins/globalize/cultures/globalize.culture.ja-JP.js"></script>

  <script type="text/javascript" src="assets/js/app.js"></script>
  <script type="text/javascript" src="assets/js/plugins.js"></script>


  <script type="text/javascript" src="assets/js/plugins.form-components.js"></script>

  <script>
  $(document).ready(function(){
    "use strict";

    App.init(); // Init layout and core plugins
    Plugins.init(); // Init all plugins
    FormComponents.init(); // Init all form-specific plugins
  });
  </script>

  <script type="text/javascript" src="assets/js/custom.js"></script>
  <script type="text/javascript" src="assets/js/demo/form_components.js"></script>
</head>

<body>